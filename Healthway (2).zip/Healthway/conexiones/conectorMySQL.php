<?php
    global $dirBaseFile;
    require_once($dirBaseFile . '/includes/db/dbConfig.php');

    class ConexionDb
    {
        public static function connect()
        {
            global $db_servername, $db_username, $db_password, $db_name, $conn;

            try {

                if (!isset($conn) || $conn === null) {

                    $conn = new PDO(
                        "mysql:host=$db_servername;dbname=$db_name;charset=utf8",
                        $db_username,
                        $db_password
                    );

                    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                }

                return $conn; // ← IMPORTANTE

            } catch (PDOException $e) {
                throw new Exception("Error en la conexión a la BD: " . $e->getMessage());
            }
        }

        public static function disconnect()
        {
            global $conn;
            $conn = null;
        }

        public static function consult($query, $params = null)
        {
            global $conn;

            if (!isset($conn) || $conn === null) {
                $conn = self::connect(); // ← aseguro conexión
            }

            try {
                $stmt = $conn->prepare($query);

                if (is_array($params)) {
                    foreach ($params as $param) {
                        $stmt->bindValue($param["clave"], $param["valor"]);
                    }
                }

                $stmt->execute();
                return $stmt->fetchAll(PDO::FETCH_ASSOC);

            } catch (Exception $e) {
                throw new Exception("Error al consultar BD ($query): " . $e->getMessage());
            }
        }

        public static function consultOne($sql, $params = [])
        {
            global $conn;

            if (!isset($conn) || $conn === null) {
                $conn = self::connect(); // ← aseguro conexión
            }

            $stmt = $conn->prepare($sql);

            if ($params) {
                foreach ($params as $p) {
                    $stmt->bindValue($p["clave"], $p["valor"]);
                }
            }

            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC); 
        }
    }
?>