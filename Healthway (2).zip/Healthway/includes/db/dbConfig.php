<?php
    $db_servername = "localhost";
    $db_username = "root";
    $db_password = "";
    $db_name = "healthway";

    $db_strconn = "mysql:host=$db_servername;dbname=$db_name;charset=utf8";

    /** @var PDO $conn */
    $conn = null;
?>