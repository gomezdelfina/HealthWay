<?php
    session_start();

    // url frontend
    $dirBaseUrl = '/HTML/Healthway'; // ← corregido el typo
    $dirBaseFile = realpath($_SERVER['DOCUMENT_ROOT'] . $dirBaseUrl);

    // var
    $errors = [];
    $module = '';
?>