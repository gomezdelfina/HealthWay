<?php
// Datos de conexión
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "healthway"; // <-- tu base de datos

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Leer el archivo JSON
    $json = file_get_contents("Habitaciones.json");
    $habitaciones = json_decode($json, true);

    // Preparar la consulta SQL
    $sql = "INSERT INTO habitaciones (IdHabitacion, NumeroHabitacion, TipoHabitacion, Habilitada)
            VALUES (:IdHabitacion, :NumeroHabitacion, :TipoHabitacion, :Habilitada)";
    $stmt = $pdo->prepare($sql);

    // Recorrer e insertar cada registro
    foreach ($habitaciones as $hab) {
        $stmt->execute([
            ":IdHabitacion" => $hab["IdHabitacion"],
            ":NumeroHabitacion" => $hab["NumeroHabitacion"],
            ":TipoHabitacion" => $hab["TipoHabitacion"],
            ":Habilitada" => $hab["Habilitada"]
        ]);
    }

    echo "✅ Habitaciones insertadas correctamente en la base de datos.";

} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage();
}
?>