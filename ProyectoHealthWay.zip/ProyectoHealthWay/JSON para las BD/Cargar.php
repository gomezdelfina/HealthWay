<?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "healthway";

    try {

        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        echo "Conexión exitosa\n";

    } catch(PDOException $e) {

        die("Error de conexión: " . $e->getMessage());

    }

    // Función para leer JSON
    function cargarJSON($archivo) {

        $data = file_get_contents($archivo);
        return json_decode($data, true);

    }

    // Insertar Roles
    $roles = cargarJSON("roles.json");

    $stmt = $pdo->prepare("INSERT INTO Roles (IdRol, DescRol) VALUES (:IdRol, :DescRol)");

    foreach ($roles as $rol) {

        $stmt->execute([

            ":IdRol" => $rol['IdRol'],
            ":DescRol" => $rol['DescRol']

        ]);
    }
    echo "Roles insertados\n";

    // Insertar Obras Sociales
    $obras = cargarJSON("obras_sociales.json");

    $stmt = $pdo->prepare("INSERT INTO ObrasSociales (IdOS, NombreOS) VALUES (:IdOS, :NombreOS)");

    foreach ($obras as $os) {

        $stmt->execute([

            ":IdOS" => $os['IdOS'],
            ":NombreOS" => $os['NombreOS']

        ]);
    }
    echo "Obras Sociales insertadas\n";

    // Insertar Planes de Obras Sociales
    $planes = cargarJSON("planes_obras_sociales.json");

    $stmt = $pdo->prepare("INSERT INTO Planes_ObrasSociales (IdPlan, IdOS, NombrePlan, TipoHabitacion, HorasInternacion) 
                        VALUES (:IdPlan, :IdOS, :NombrePlan, :TipoHabitacion, :HorasInternacion)");
    
    foreach ($planes as $plan) {

        $stmt->execute([

            ":IdPlan" => $plan['IdPlan'],
            ":IdOS" => $plan['IdOS'],
            ":NombrePlan" => $plan['NombrePlan'],
            ":TipoHabitacion" => $plan['TipoHabitacion'],
            ":HorasInternacion" => $plan['HorasInternacion']

        ]);

    }
    echo "Planes insertados\n";

    // Insertar Direcciones
    $direcciones = cargarJSON("direcciones.json");

    $stmt = $pdo->prepare("INSERT INTO Direcciones (IdDireccion, Direccion, Numero, Ciudad, Provincia, Pais) 
                        VALUES (:IdDireccion, :Direccion, :Numero, :Ciudad, :Provincia, :Pais)");

    foreach ($direcciones as $dir) {

        $stmt->execute([

            ":IdDireccion" => $dir['IdDireccion'],
            ":Direccion" => $dir['Direccion'],
            ":Numero" => $dir['Numero'],
            ":Ciudad" => $dir['Ciudad'],
            ":Provincia" => $dir['Provincia'],
            ":Pais" => $dir['Pais']

        ]);

    }

    echo "Direcciones insertadas\n";

    // Insertar Usuarios
    $usuarios = cargarJSON("usuarios.json");

    $stmt = $pdo->prepare("INSERT INTO Usuarios 
    (IdUsuario, IdRol, Usuario, Clave, Habilitado, Nombre, Apellido, Email, Telefono) 
    VALUES 
    (:IdUsuario, :IdRol, :Usuario, :Clave, :Habilitado, :Nombre, :Apellido, :Email, :Telefono)");

    foreach ($usuarios as $u) {

        $stmt->execute([

            ":IdUsuario" => $u['IdUsuario'],
            ":IdRol" => $u['IdRol'],
            ":Usuario" => $u['Usuario'],
            ":Clave" => $u['Clave'],
            ":Habilitado" => $u['Habilitado'],
            ":Nombre" => $u['Nombre'],
            ":Apellido" => $u['Apellido'],
            ":Email" => $u['Email'],
            ":Telefono" => $u['Telefono']

        ]);

    }

    echo "Usuarios insertados\n";

    // Insertar Pacientes
    $pacientes = cargarJSON("pacientes.json");

    $stmt = $pdo->prepare("INSERT INTO Pacientes 
    (IdPaciente, IdUsuario, IdOS, IdDireccion, FechaNac, Genero, DNI, EstadoCivil, Habilitado) 
    VALUES 
    (:IdPaciente, :IdUsuario, :IdOS, :IdDireccion, :FechaNac, :Genero, :DNI, :EstadoCivil, :Habilitado)");

    foreach ($pacientes as $p) {

        $stmt->execute([

            ":IdPaciente" => $p['IdPaciente'],
            ":IdUsuario" => $p['IdUsuario'],
            ":IdOS" => $p['IdOS'],
            ":IdDireccion" => $p['IdDireccion'],
            ":FechaNac" => $p['FechaNac'],
            ":Genero" => $p['Genero'],
            ":DNI" => $p['DNI'],
            ":EstadoCivil" => $p['EstadoCivil'],
            ":Habilitado" => $p['Habilitado']

        ]);

    }

    echo "Pacientes insertados\n";

    echo "Todos los datos han sido insertados correctamente.\n";
?>