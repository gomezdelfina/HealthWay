<?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "healthway";

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Leer el archivo JSON
        $jsonData = file_get_contents('solicitudes.json');
        $solicitudes = json_decode($jsonData, true);

        if (!$solicitudes) {
            throw new Exception("Error al leer o decodificar el archivo JSON.");
        }

        // Insertar los datos
        $sql = "INSERT INTO SolicitudesInternacion 
                (IdPaciente, TipoSolicitud, EstadoSolicitud, MotivoSolicitud, observacion_cierre)
                VALUES (:IdPaciente, :TipoSolicitud, :EstadoSolicitud, :MotivoSolicitud, :observacion_cierre)";
        $stmt = $pdo->prepare($sql);

        foreach ($solicitudes as $solicitud) {
            $stmt->execute([
                ':IdPaciente' => $solicitud['IdPaciente'],
                ':TipoSolicitud' => $solicitud['TipoSolicitud'],
                ':EstadoSolicitud' => $solicitud['EstadoSolicitud'],
                ':MotivoSolicitud' => $solicitud['MotivoSolicitud'],
                ':observacion_cierre' => $solicitud['observacion_cierre']
            ]);
        }

        echo "✅ Solicitudes cargadas correctamente en la base de datos.";

    } catch (Exception $e) {
        echo "❌ Error: " . $e->getMessage();
    }
?>