<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "healthway";

try {
    // 1️⃣ Conexión
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 2️⃣ Leer archivos JSON
    $jsonHabitaciones = file_get_contents('Habitaciones.json');
    $jsonCamas = file_get_contents('camas.json');

    $habitaciones = json_decode($jsonHabitaciones, true);
    $camas = json_decode($jsonCamas, true);

    if (!$habitaciones || !$camas) {
        die("❌ Error: no se pudieron leer o decodificar los archivos JSON.");
    }

    // 3️⃣ Limpiar tablas (opcional si querés reiniciar datos)
    $pdo->exec("DELETE FROM camas");
    $pdo->exec("DELETE FROM habitaciones");
    $pdo->exec("ALTER TABLE habitaciones AUTO_INCREMENT = 1");
    $pdo->exec("ALTER TABLE camas AUTO_INCREMENT = 1");

    // 4️⃣ Insertar Habitaciones
    $sqlHab = "INSERT INTO habitaciones (IdHabitacion, NumeroHabitacion, TipoHabitacion, Habilitada)
               VALUES (:idHabitacion, :numero, :tipo, :habilitada)";
    $stmtHab = $pdo->prepare($sqlHab);

    foreach ($habitaciones as $hab) {
        $stmtHab->execute([
            ':idHabitacion' => $hab['IdHabitacion'],
            ':numero' => $hab['NumeroHabitacion'],
            ':tipo' => $hab['TipoHabitacion'],
            ':habilitada' => $hab['Habilitada']
        ]);
    }

    // 5️⃣ Insertar Camas
    $sqlCama = "INSERT INTO camas (IdHabitacion, NumeroCama, EstadoCama, Habilitada)
                VALUES (:idHabitacion, :numeroCama, :estado, :habilitada)";
    $stmtCama = $pdo->prepare($sqlCama);

    foreach ($camas as $cama) {
        $stmtCama->execute([
            ':idHabitacion' => $cama['IdHabitacion'],
            ':numeroCama' => $cama['NumeroCama'],
            ':estado' => $cama['EstadoCama'],
            ':habilitada' => $cama['Habilitada']
        ]);
    }

    echo "✅ Datos importados correctamente: " . count($habitaciones) . " habitaciones y " . count($camas) . " camas.";

} catch (PDOException $e) {
    echo "❌ Error en la base de datos: " . $e->getMessage();
}
?>
