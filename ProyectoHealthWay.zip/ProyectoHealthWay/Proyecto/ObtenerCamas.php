<?php
    header('Content-Type: application/json; charset=utf-8');

    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "healthway";

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(["error" => "Error al conectar con la base de datos", "detalle" => $e->getMessage()]);
        exit;
    }

    // 🔹 Paginación
    $porPagina = 30;
    $pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
    $offset = ($pagina - 1) * $porPagina;

    // 🔹 Consulta principal
    $stmt = $pdo->prepare("
        SELECT 
            c.IdCama,
            c.NumeroCama,
            c.Habilitada,
            c.EstadoCama,
            h.NumeroHabitacion,
            i.IdInternacion,
            i.EstadoInternacion,
            CONCAT(u.Nombre, ' ', u.Apellido) AS NombrePaciente
        FROM camas c
        LEFT JOIN habitaciones h ON c.IdHabitacion = h.IdHabitacion
        LEFT JOIN internaciones i 
            ON c.IdCama = i.IdCama 
            AND i.EstadoInternacion IN ('Activa','Reprogramada','Trasladada')
        LEFT JOIN pacientes p ON i.IdPaciente = p.IdPaciente
        LEFT JOIN usuarios u ON p.IdUsuario = u.IdUsuario
        ORDER BY c.NumeroCama ASC
        LIMIT :offset, :porPagina
    ");

    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->bindValue(':porPagina', $porPagina, PDO::PARAM_INT);
    $stmt->execute();
    $filas = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 🔹 Total de camas
    $totalStmt = $pdo->query("SELECT COUNT(*) FROM camas");
    $totalCamas = $totalStmt->fetchColumn();
    $totalPaginas = ceil($totalCamas / $porPagina);

    // 🔹 Respuesta JSON
    echo json_encode([
        'camas' => $filas ?: [],
        'totalPaginas' => $totalPaginas
    ]);
?>