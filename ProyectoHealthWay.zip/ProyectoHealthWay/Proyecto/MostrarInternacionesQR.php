<?php
$host = "localhost";
    $username = "root";
    $password = "";
    $db = "healthway";

    try {

        $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $username, $password);
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    } catch (PDOException $e) {

        error_log($e->getMessage());
        die("Error al conectar con la base de datos.");

    }

    if (!isset($_GET['id'])) {
        die("ID no especificado");
    }

    $id = $_GET['id'];

    $stmt = $conn->prepare("
        SELECT 
                i.IdInternacion,
                i.IdCama,
                i.IdHabitacion,
                i.FechaInicio,
                i.FechaFin,
                i.EstadoInternacion,
                CONCAT(u.Nombre, ' ', u.Apellido) AS NombrePaciente
            FROM internaciones i
            INNER JOIN pacientes p ON i.IdPaciente = p.IdPaciente
            INNER JOIN usuarios u ON p.IdUsuario = u.IdUsuario
            WHERE i.IdInternacion = :id
    ");
    $stmt->execute([":id" => $id]);

    $data = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$data) {
        die("Internación no encontrada");
    }
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Datos de la Internación</title>
</head>
<body>
    <h2>Internación Nº <?= $data["IdInternacion"] ?></h2>

    <p><b>Paciente:</b> <?= $data["NombrePaciente"] ?></p>
    <p><b>Cama:</b> <?= $data["IdCama"] ?></p>
    <p><b>Habitación:</b> <?= $data["IdHabitacion"] ?></p>
    <p><b>Estado:</b> <?= $data["EstadoInternacion"] ?></p>
    <p><b>Inicio:</b> <?= $data["FechaInicio"] ?></p>
    <p><b>Fin:</b> <?= $data["FechaFin"] ?></p>

</body>
</html>