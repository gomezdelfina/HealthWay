<?php
    header('Content-Type: application/json; charset=utf-8');

    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "healthway";

    try {

        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);

    } catch (PDOException $e) {

        http_response_code(500);
        echo json_encode(["error" => "Error de conexión a la base de datos", "detalle" => $e->getMessage()]);
        exit;

    }

    if (!isset($_GET['idPaciente']) || !is_numeric($_GET['idPaciente'])) {
        
        echo json_encode([]);
        exit;

    }

    $idPaciente = intval($_GET['idPaciente'] ?? 0);

    try {

        $sql = "SELECT IdSolicitud, TipoSolicitud, EstadoSolicitud, FechaCreacion, MotivoSolicitud
                FROM solicitudesinternacion
                WHERE IdPaciente = :idPaciente AND EstadoSolicitud = 'Abierta'";

        $stmt = $pdo->prepare($sql);

        $stmt->execute(['idPaciente' => $idPaciente]);

        $solicitudes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($solicitudes, JSON_UNESCAPED_UNICODE);

    } catch (PDOException $e) {

        echo json_encode([]);

    }
?>