<?php
    header('Content-Type: application/json');

    // Conexión
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "healthway";

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch(PDOException $e) {
        echo json_encode([]);
        exit;
    }

    // Verificar parámetros
    if (isset($_GET['numeroHab'])) {
        $numeroHab = (int)$_GET['numeroHab'];

        try {

            $stmt = $pdo->prepare("
                SELECT 
                    c.IdCama, 
                    c.NumeroCama
                FROM 
                    camas c
                JOIN 
                    habitaciones h ON c.IdHabitacion = h.IdHabitacion
                WHERE 
                    (h.IdHabitacion = :numeroHab OR h.NumeroHabitacion = :numeroHab)
                    AND c.EstadoCama = 'Disponible'
                    AND c.Habilitada = 1
            ");

            $stmt->bindParam(':numeroHab', $numeroHab, PDO::PARAM_INT);
            $stmt->execute();

            // Devolver las camas disponibles como JSON
            echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));

        } catch (PDOException $e) {

            // En caso de error, devolver JSON vacío o mensaje
            error_log($e->getMessage());
            echo json_encode(['error' => 'Error al obtener las camas disponibles.']);

        }

    exit;
}

    echo json_encode([]);
?>