<?php
    header('Content-Type: application/json');

    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "healthway";

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch(PDOException $e) {
        echo json_encode([]);
        exit;
    }

    // Determinar qué tipo de datos devolver según la región
    if (isset($_GET['tipoHab'])) {

        $tipo = $_GET['tipoHab'];

        if ($tipo === "Compartida") {

            $stmt = $pdo->prepare("SELECT IdHabitacion, NumeroHabitacion FROM habitaciones WHERE TipoHabitacion = 'Compartida'");
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        } elseif ($tipo === "Individual") {

            $stmt = $pdo->prepare("SELECT IdHabitacion, NumeroHabitacion FROM habitaciones WHERE TipoHabitacion = 'Individual'");
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        } else {

            $result = [];

        }

        echo json_encode($result);
        exit;
    }

    echo json_encode([]);
?>