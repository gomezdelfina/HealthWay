document.addEventListener('DOMContentLoaded', function() {

    AparecerIndividual();
    AparecerCompartida();
    AparecerCamaIndividual();
    AparecerCamaCompartida();
    OpcionPaciente();
    OpcionSolicitud();
    OpcionHabitacion();
    OpcionCama();

});


function AparecerCompartida() {
    const Habitacion = document.getElementById("habitacionPac");
    const Compartida = document.getElementById("DivComp");

    Habitacion.addEventListener("change", function () {
        const seleccion = this.value;

        if (seleccion === "Compartida") {

            Compartida.style.display = "block";

        } else {

            Compartida.style.display = "none";

        }
    })
}

function AparecerIndividual() {
    const Habitacion = document.getElementById("habitacionPac");
    const Individual = document.getElementById("DivInd");

    Habitacion.addEventListener("change", function () {
        const seleccion = this.value;

        if (seleccion === "Individual") {

            Individual.style.display = "block";

        } else {

            Individual.style.display = "none";

        }
    })
}

function AparecerCamaCompartida() {
    const Cama = document.getElementById("camaComPac");
    const Compartida = document.getElementById("DivCama");

    Cama.addEventListener("change", function () {
        const seleccion = this.value;

        if (seleccion !== "") {

            Compartida.style.display = "block";

        } else {

            Compartida.style.display = "none";

        }
    })
}

function AparecerCamaIndividual() {
    const Habitacion = document.getElementById("camaIndPac");
    const Individual = document.getElementById("DivCama");

    Habitacion.addEventListener("change", function () {
        const seleccion = this.value;

        if (seleccion !== "") {

            Individual.style.display = "block";

        } else {

            Individual.style.display = "none";

        }
    })
}

function OpcionPaciente() {
    const selectPacientes = document.getElementById("paciente");

    fetch("InternacionPaciente.php") // archivo PHP que devuelve los pacientes

        .then(response => response.json())
        .then(data => {

            // Limpia opciones previas y agrega la opción inicial
            selectPacientes.innerHTML = "";
            const firstOption = document.createElement('option');
            firstOption.value = "";
            firstOption.textContent = "Seleccionar un paciente";
            selectPacientes.appendChild(firstOption);

            // Itera sobre cada paciente recibido
            data.forEach(item => {

                const option = document.createElement('option');
                option.value = item.IdPaciente;
                option.textContent = `${item.Apellido}, ${item.Nombre} - DNI: ${item.DNI}`;
                selectPacientes.appendChild(option);

            });

        })

        .catch(error => {

            console.error("Error cargando pacientes:", error);
            const errorOption = document.createElement('option');
            errorOption.value = "";
            errorOption.textContent = "Error al cargar pacientes";
            selectPacientes.appendChild(errorOption);

    });
}

function OpcionSolicitud() {
    const selectPacientes = document.getElementById('paciente');
    const selectSolicitudes = document.getElementById('solicitud');

    function cargarSolicitudes() {
        const idPaciente = selectPacientes.value;

        // Limpiar solicitudes
        selectSolicitudes.innerHTML = '<option value="">Seleccione una solicitud</option>';
        if (idPaciente === "") return;

        fetch('InternacionSolicitud.php?idPaciente=' + idPaciente)
        
            .then(res => res.json())
            .then(data => {

                data.forEach(item => {

                    const option = document.createElement('option');
                    option.value = item.IdSolicitud;
                    option.textContent = `${item.TipoSolicitud} - ${item.FechaCreacion}`;
                    selectSolicitudes.appendChild(option);

                });

            })

            .catch(err => console.error("Error al cargar solicitudes:", err));
    }

    // El listener se agrega aquí, **después de que el select exista y tenga opciones**
    selectPacientes.addEventListener('change', cargarSolicitudes);
}


function OpcionHabitacion() {
    const selectHabitacion = document.getElementById('habitacionPac');
    const selectCompartida = document.getElementById('camaComPac');
    const selectIndividual = document.getElementById('camaIndPac');

    selectHabitacion.addEventListener('change', function() {
        const valor = this.value;

        // Limpiar selects
        selectCompartida.innerHTML = '<option value=""> Seleccione Primero Un Tipo de Habitacion </option>';
        selectIndividual.innerHTML = '<option value=""> Seleccione Primero Un Tipo de Habitacion </option>';

            if (valor === "" ) return;

            // AJAX usando fetch
            fetch('InternacionHabitacion.php?tipoHab=' + valor)

            .then(response => response.json())
            .then(data => {

                if (valor === "Compartida") {

                    data.forEach(item => {

                        const option = document.createElement('option');
                        option.value = item.IdHabitacion;
                        option.textContent = item.NumeroHabitacion;
                        selectCompartida.appendChild(option);

                    });

                } else if (valor === "Individual") {

                    data.forEach(item => {

                        const option = document.createElement('option');
                        option.value = item.IdHabitacion;
                        option.textContent = item.NumeroHabitacion;
                        selectIndividual.appendChild(option);

                    });
                }
            })

        .catch(error => console.error('Error AJAX:', error));
    });
}

function OpcionCama() {
    const selectCompartida = document.getElementById('camaComPac');
    const selectIndividual = document.getElementById('camaIndPac');
    const selectCama = document.getElementById('camaPac');
    const divCama = document.getElementById('DivCama');

    function cargarCamas(origen) {
        const numeroHab = origen.value;

        if (!numeroHab) {
            selectCama.innerHTML = '<option value="">Seleccione una cama</option>';
            divCama.style.display = "none";
            return;
        }

        selectCama.innerHTML = '<option>Cargando camas...</option>';

        fetch(`InternacionCama.php?numeroHab=${encodeURIComponent(numeroHab)}`)
            .then(r => r.json())
            .then(data => {
                selectCama.innerHTML = '<option value="">Seleccione una cama</option>';

                if (Array.isArray(data) && data.length > 0) {
                    data.forEach(cama => {
                        const option = document.createElement('option');
                        option.value = cama.IdCama;
                        option.textContent = `Cama ${cama.NumeroCama}`;
                        selectCama.appendChild(option);
                    });
                    divCama.style.display = "block";
                } else {
                    selectCama.innerHTML = '<option disabled>No hay camas disponibles</option>';
                    divCama.style.display = "block";
                }
            })
            .catch(err => {
                console.error('Error:', err);
                selectCama.innerHTML = '<option>Error al cargar camas</option>';
            });
    }

    selectCompartida.addEventListener("change", function() {
        selectIndividual.value = "";
        cargarCamas(this);
    });

    selectIndividual.addEventListener("change", function() {
        selectCompartida.value = "";
        cargarCamas(this);
    });
}
