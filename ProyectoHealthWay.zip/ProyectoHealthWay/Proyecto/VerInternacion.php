<?php
    header('Content-Type: application/json;');

    $host = "localhost";
    $username = "root";
    $password = "";
    $db = "healthway";

    try {

        $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $username, $password);
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    } catch (PDOException $e) {

        error_log($e->getMessage());
        die("Error al conectar con la base de datos.");

    }

    if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
        echo json_encode(['error' => 'ID de internación inválido']);
        exit;
    }

    $id = (int)$_GET['id'];

    try {
        
        $stmt = $conn->prepare("
            SELECT 
                i.IdInternacion,
                i.IdCama,
                i.IdHabitacion,
                i.FechaInicio,
                i.FechaFin,
                i.EstadoInternacion,
                CONCAT(u.Nombre, ' ', u.Apellido) AS NombrePaciente
            FROM internaciones i
            INNER JOIN pacientes p ON i.IdPaciente = p.IdPaciente
            INNER JOIN usuarios u ON p.IdUsuario = u.IdUsuario
            WHERE i.IdInternacion = :id
        ");

        $stmt->execute([':id' => $id]);
        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        echo json_encode($data ?: ['error' => 'Internación no encontrada']);

    } catch (PDOException $e) {

        error_log($e->getMessage());
        echo json_encode(['error' => 'Error al obtener datos de internación']);

    }
?>