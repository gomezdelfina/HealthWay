<?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "healthway";

    // ID de la internación
    $id = $_GET['id'] ?? null;

    if (!$id) {
        exit("ID no proporcionado");
    }

    try {
        $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);

        // Obtener el QR en binario
        $stmt = $conn->prepare("SELECT qr FROM internaciones WHERE IdInternacion = :id");
        $stmt->execute([":id" => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row && !empty($row['qr'])) {
            header("Content-Type: image/png");
            echo $row['qr']; // Muestra directamente la imagen
        } else {
            echo "QR no encontrado.";
        }

    } catch (PDOException $e) {
        echo "Error DB: " . $e->getMessage();
    }
?>