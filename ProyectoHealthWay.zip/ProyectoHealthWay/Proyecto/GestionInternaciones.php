<?php
    $host = "localhost";
    $username = "root";
    $password = "";
    $db = "healthway";

    try {

        $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $username, $password);
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    } catch (PDOException $e) {

        error_log($e->getMessage());
        die("Error al conectar con la base de datos.");

    }
?>

<?php

    require_once "phpqrcode/qrlib.php";
    
    $paciente = $solicitud = $estado = $habitacion = $cama = $fechaInicio = $fechaFin = "";

    $errores = [];

    if ($_SERVER["REQUEST_METHOD"] === "POST") {

        if (!empty($_POST["paciente"])) {

            $paciente = $_POST["paciente"];

        } else {

            $errores["paciente"] = "Paciente no Seleccionado";

        }

        if (!empty($_POST["solicitud"])) {

            $solicitud = $_POST["solicitud"];

        } else {

            $errores["solicitud"] = "Solicitud no Seleccionada";

        }

        if (!empty($_POST["estado"])){

            $estado = $_POST["estado"];

        } else {

            $errores["estado"] = 'Estado no Seleccionado';

        }

        if(!empty($_POST["individual"])) {

            $habitacion = $_POST["individual"];

        } else if (!empty($_POST["compartida"])) {

            $habitacion = $_POST["compartida"];

        } else {

            $errores["individual"] = "Habitacion No Seleccionada";
            $errores["compartida"] = "Habitacion No Seleccionada";

        }

        if (!empty($_POST["cama"])) {

            $cama = $_POST["cama"];

        } else {

            $errores["cama"] = "Cama no Seleccionada";

        }

        if (empty($_POST["fechaInicio"])) {

            $errores["fechaInicio"] = "La fecha de inicio es obligatoria.";

        } else {

            $fechaInicio = $_POST["fechaInicio"];

        }

        if (empty($_POST["fechaFin"])) {

            $errores["fechaFin"] = "La fecha de fin es obligatoria.";

        } else {

            $fechaFin = $_POST["fechaFin"];

        }

        if (!empty($fechaInicio) && !empty($fechaFin)) {

            try {

                $inicio = new DateTime($fechaInicio);
                $fin    = new DateTime($fechaFin);

                if ($fin < $inicio) {

                    $errores["fechaFin"] = "La fecha de fin no puede ser anterior a la fecha de inicio.";

                }

            } catch (Exception $e) {

                $errores["fechaFin"] = "Formato de fecha inválido.";

            }
        }

        if (empty($errores)) {

            try {

                $conn->beginTransaction();

                // 1) Insertar internación
                $stmt = $conn->prepare("
                    INSERT INTO internaciones 
                    (IdSolicitud, IdCama, IdHabitacion, IdPaciente, FechaInicio, FechaFin, EstadoInternacion)
                    VALUES 
                    (:solicitud, :cama, :habitacion, :paciente, :inicio, :fin, :estado)
                ");

                $stmt->execute([
                    ":solicitud" => $solicitud,
                    ":cama" => $cama,
                    ":habitacion" => $habitacion,
                    ":paciente" => $paciente,
                    ":inicio" => $fechaInicio,
                    ":fin" => $fechaFin,
                    ":estado" => $estado
                ]);

                // 2) Obtener ID generado
                $idInternacion = $conn->lastInsertId();

                $idInternacion = $conn->lastInsertId();

                // 1) URL REAL hacia el archivo que muestra la internación
                $url = "http://192.168.1.33/HTML/PDO/ProyectoHealthWay/Proyecto/MostrarInternacionesQR.php?id=" . $idInternacion;

                // 2) Generar QR capturando su salida
                ob_start();
                QRcode::png($url, null, QR_ECLEVEL_L, 5);
                $qrImage = ob_get_clean();

                // 3) Guardar el QR como blob
                $stmtQR = $conn->prepare("
                    UPDATE internaciones 
                    SET qr = :qr
                    WHERE IdInternacion = :id
                ");

                $stmtQR->bindParam(":qr", $qrImage, PDO::PARAM_LOB);
                $stmtQR->bindParam(":id", $idInternacion, PDO::PARAM_INT);
                $stmtQR->execute();

                // Actualizar Cama
                $stmt2 = $conn->prepare("UPDATE camas 
                                        SET 
                                            EstadoCama = 'Ocupada',
                                            Habilitada = 0
                                        WHERE IdCama = :cama AND EstadoCama = 'Disponible' AND Habilitada = 1
                ");

                $stmt2->execute([':cama' => $cama]);

                // Actualizar Solicitud
                $stmt3 = $conn->prepare("UPDATE solicitudesinternacion
                                        SET 
                                            EstadoSolicitud = 'Cerrada'
                                        WHERE IdSolicitud = :solicitud AND EstadoSolicitud = 'Abierta'
                ");
                $stmt3->execute([':solicitud' => $solicitud]); 

                // Actualizar Paciente
                $stmt4 = $conn->prepare("UPDATE pacientes
                                        SET
                                            Estado = 'Internado'
                                        WHERE IdPaciente = :paciente AND Estado = 'Normal'                
                ");

                $stmt4->execute([':paciente' => $paciente]);  

                // Verificar si realmente se actualizó
                if ($stmt2->rowCount() === 0) {

                    throw new Exception("La cama seleccionada ya no está disponible.");

                }

                if ($stmt3->rowCount() === 0) {

                    throw new Exception("La Solicitud seleccionada ya está cerrada.");

                }

                if ($stmt4->rowCount() === 0) {

                    throw new Exception("El Paciente seleccionado ya está internado.");

                }

                // Confirmar los cambios
                $conn->commit();

            } catch (Exception $e) {

                if ($conn->inTransaction()) {

                    $conn->rollBack();

                }

                error_log($e->getMessage());
                echo "<div class='alert alert-danger'>Error al registrar la internación. Intente nuevamente.</div>";

            }
        }
    }
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- css -->
    <link href="./styles.css" rel="stylesheet">
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@200..800&display=swap" rel="stylesheet">
    <!-- javascript -->
    <script src="./scriptInternaciones.js" defer></script>
    <title>HealthWay</title>
</head>
<body>
    <div>
        <header class="container-fluid">
            <nav class="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
                <a class="navbar-brand" href="#">HealthWay</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="DashboardPersMedico.html" id="gestionDashBtn">Inicio</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="GestionInternaciones.html" id="gestionInterBtn">Internaciones</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="GestionRevisiones.html" id="gestionRevisBtn">Revisiones</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="GestionHistoriasClinicas.html" id="gestionHCBtn">Historias clinicas</a>
                        </li>
                    </ul>
                    <div class="d-flex align-items-center" id="btnCerrarSesion">
                        <span><i class="bi bi-bell-fill mx-1 me-3"></i></span>
                        <span class="me-3 text-secondary">Enfermero</span>
                        <a href="./index.html" class="btn btn-outline-danger" id="btnLinkCerrarSesion">Cerrar Sesión
                            <i class="bi bi-box-arrow-right mx-1"></i>
                        </a>
                    </div>
                </div>
            </nav>
        </header>

        <main class="container-fluid">
            <div class="background mt-3 row">
                <h1 class="mb-4 dashboard-title">Gestion de Internaciones</h1>

                <div class="row mb-4 align-items-center">
                    <div class="col-md-4">
                        <button class="btn btn-success btn-lg" data-bs-toggle="modal" data-bs-target="#addUserModal">
                            <i class="bi bi-person-plus-fill me-2"></i>Añadir Nueva Internacion
                        </button>
                    </div>
                    <div class="col-md-8">
                        <div class="input-group">
                            <input type="text" id="buscarInput" class="form-control" placeholder="Buscar por Paciente, Cama o Habitación" title="buscar">
                            <button class="btn btn-outline-primary" id="btnBuscar" type="button">
                                <i class="bi bi-search"></i> Buscar
                            </button>
                        </div>
                    </div>
                </div>

                <div class="col-12">
                    <div class="card shadow-sm">
                        <div class="card-header text-white card-header-color">
                            <i class="bi bi bi-card-list bi-hospital me-2"></i>Lista de Internaciones Activas
                        </div>
                        <div class="card-body">

                            <div id="tablaInternaciones">

                                <div class="container mt-4">

                                    <div class="row" id="contenedorCamas">

                                        <!-- Acá se insertarán automáticamente las 150 camas -->

                                    </div>

                                </div>

                            </div> 
                        </div>
                        <nav aria-label="Page navigation">
                            <ul class="pagination justify-content-end"></ul>
                        </nav>
                    </div>
                </div>
                
                <div class="modal fade" id="modalInternacion" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title h4-modal-header" id="modalLabel">Internacion</h4>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>

                            <div class="modal-body div-modal-body">
                                <form id="InternacionForm">
                                    <div class="row">
                                        <div class="col-4">
                                            <label class="form-label" for="interNumber">N. Internacion</label>
                                            <input class="form-control" id="interNumber" name="nInter" readonly>
                                        </div>
                                        <div class="col-4">
                                            <label class="form-label" for="nombrePac">Nombre</label>
                                            <input class="form-control" id="nombrePac" name="nombrePac" readonly>
                                        </div>
                                        <div class="col-4">
                                            <label class="form-label" for="camaInter">Cama</label>
                                            <input class="form-control" id="camaInter" name="camaInter" value="" readonly>
                                        </div>
                                        <div class="col-4">
                                            <label class="form-label" for="habInter">Habitacion</label>
                                            <input class="form-control" id="habInter" name="habInter" readonly>
                                        </div>
                                        <div class="col-4">
                                            <label class="form-label" for="estadoInter">Estado</label>
                                            <input class="form-control" id="estadoInter" name="estadobInter" readonly>
                                        </div>
                                        <div class="col-4">
                                            <label class="form-label" for="fechaInter">Fecha de Internacion</label>
                                            <input class="form-control" id="fechaInter" name="fechaInter" readonly>
                                        </div>
                                        <div class="col-4">
                                            <label class="form-label" for="fechaFinInter">Fecha Final de Internacion</label>
                                            <input class="form-control" id="fechaFinInter" name="fechaFinInter" readonly>
                                        </div>
                                        <div class="col-6">
                                            <label class="form-label" for="notasInter">Notas</label>
                                            <input class="form-control" id="notasInter" name="notasInter" readonly>
                                        </div>
                                    </div>
                                </form>
                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn-cancelEmail" form="pswRecoveryForm" id="btnPswRecovery" data-bs-dismiss="modal">Cancelar</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="addUserModalLabel"> Crear Nueva Internacion </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>

                            <div class="modal-body">

                                <form id="registerform" action="" method="post">

                                    <div class="row mb-3">

                                        <label for="paciente" class="form-label">Seleccionar Paciente</label>
                                            <select class="form-select <?php if (isset($errores["paciente"])) { echo "is-invalid"; } ?>" 
                                                id="paciente" name="paciente">
                                                <option value=""> Seleccionar un Paciente </option>
                                            </select>

                                        <div class="invalid-feedback">

                                            <?php if (isset($errores["paciente"])) { echo $errores["paciente"]; } ?>

                                        </div>
                                        
                                    </div>

                                    <div class="row mb-3">

                                        <label for="solicitud" class="form-label"> Solicitud de Internacion </label>
                                            <select class="form-select <?php if (isset($errores["solicitud"])) { echo "is-invalid"; } ?>"
                                                id="solicitud" name="solicitud">
                                                <option value=""> Seleccionar una Solicitud </option>
                                            </select>

                                        <div class="invalid-feedback">

                                            <?php if (isset($errores["solicitud"])) { echo $errores["solicitud"]; } ?>

                                        </div>

                                    </div>

                                    <div class="row mb-3">

                                        <label for="estado" class="form-label"> Estado de Internacion </label>
                                        <select class="form-select <?php if (isset($errores["estado"])) { echo "is-invalid"; } ?>"
                                        id="estado" name="estado">
                                            <option selected> Seleccione un Estado </option>
                                            <option value="Activa"> Activa </option>
                                            <option value="Trasladada"> Trasladada </option>
                                            <option value="Reprogramada"> Reprogramada </option>
                                        </select>

                                        <div class="invalid-feedback">

                                            <?php if (isset($errores["estado"])) { echo $errores["estado"]; } ?>

                                        </div>
                                    
                                    </div>
                                    

                                    <div class="row mb-3">

                                        <label class="form-label" for="habitacionPac">Habitacion</label>
                                        <select class="form-select <?php if (isset($errores["habitacion"])) { echo "is-invalid"; } ?>"
                                        id="habitacionPac" name="habitacion">
                                            <option value=""> Seleccione Un Tipo de Habitacion </option>
                                            <option value="Compartida"> Compartida </option>
                                            <option value="Individual"> Individual </option>
                                        </select>

                                        <div class="invalid-feedback">

                                            <?php if (isset($errores["habitacion"])) { echo $errores["habitacion"]; } ?>

                                        </div>
                                            
                                    </div>

                                    <div id="DivComp" class="row mb-3">

                                        <label class="form-label" for="camaComPac"> Tipo de Habitacion</label>
                                        <select class="form-select <?php if (isset($errores["compartida"])) { echo "is-invalid"; } ?>"
                                        id="camaComPac" name="compartida">
                                            <option value=""> Seleccione Primero Un Tipo de Habitacion </option>
                                        </select>

                                        <div class="invalid-feedback">

                                            <?php if (isset($errores["compartida"])) { echo $errores["compartida"]; } ?>

                                        </div>

                                    </div>

                                    <div id="DivInd" class="row mb-3">

                                        <label class="form-label" for="camaIndPac">Habitacion</label>
                                        <select class="form-select <?php if (isset($errores["individual"])) { echo "is-invalid"; } ?>"
                                        id="camaIndPac" name="individual">
                                            <option value=""> Seleccione Primero Un Tipo de Habitacion </option>
                                        </select>

                                        <div class="invalid-feedback">

                                            <?php if (isset($errores["individual"])) { echo $errores["individual"]; } ?>

                                        </div>
                                        
                                    </div>

                                    <div id="DivCama" class="row mb-3">

                                        <label class="form-label" for="camaPac">Cama</label>
                                        <select class="form-select <?php if (isset($errores["cama"])) { echo "is-invalid"; } ?>"
                                        id="camaPac" name="cama">
                                            <option value=""> Seleccione Primero Una Habitacion </option>
                                        </select>

                                        <div class="invalid-feedback">

                                            <?php if (isset($errores["cama"])) { echo $errores["cama"]; } ?>

                                        </div>
                                    
                                    </div>

                                    <div class="row mb-3">

                                        <label class="form-label" for="fechaInicio">Fecha de Inicio</label>
                                        <input type="datetime-local" class="form-control <?php if (isset($errores["fechaInicio"])) echo "is-invalid"; ?>"
                                        id="fechaInicio" name="fechaInicio">
                                            
                                        <div class="invalid-feedback">
                                                
                                            <?php if (isset($errores["fechaInicio"])) echo $errores["fechaInicio"]; ?>
                                            
                                        </div>
                                        
                                    </div>

                                    <div class="row mb-3">

                                        <label class="form-label" for="fechaFin">Fecha de Fin</label>
                                        <input type="datetime-local" class="form-control <?php if (isset($errores["fechaFin"])) echo "is-invalid"; ?>"
                                        id="fechaFin" name="fechaFin">

                                        <div class="invalid-feedback">

                                            <?php if (isset($errores["fechaFin"])) echo $errores["fechaFin"]; ?>

                                        </div>
                                        
                                    </div>

                                    <div class="modal-footer">

                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                                        <button type="submit" class="btn btn-primary"> Completar Internacion </button>

                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="./scriptcamas.js"></script>

</body>
</html>
