<?php
    header('Content-Type: application/json; charset=utf-8');

    // Conexión a la BD
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "healthway";

    try {
        $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);
    } catch (PDOException $e) {
        echo json_encode(["error" => "Error de conexión: " . $e->getMessage()]);
        exit;
    }

    $busqueda = $_GET['busqueda'] ?? '';
    $busqueda = trim($busqueda);

    if ($busqueda === '') {
        echo json_encode([]);
        exit;
    }

    $sql = "
        SELECT 
            i.IdInternacion,
            i.IdCama,
            i.IdHabitacion,
            i.EstadoInternacion,
            CONCAT(u.Nombre, ' ', u.Apellido) AS NombrePaciente
        FROM internaciones i
        INNER JOIN pacientes p ON i.IdPaciente = p.IdPaciente
        INNER JOIN usuarios u ON p.IdUsuario = u.IdUsuario
        WHERE CONCAT(u.Nombre, ' ', u.Apellido) LIKE :busqueda
        OR i.IdCama LIKE :busqueda
        OR i.IdHabitacion LIKE :busqueda
        ORDER BY i.IdInternacion DESC
    ";

    $stmt = $conn->prepare($sql);
    $stmt->execute([':busqueda' => "%$busqueda%"]);
    $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($resultados);
?>