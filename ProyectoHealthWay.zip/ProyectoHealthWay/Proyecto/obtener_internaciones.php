<?php
    // ===============================================
    // 🔹 obtener_internaciones.php
    // Devuelve las internaciones activas en formato JSON
    // ===============================================

    header('Content-Type: application/json; charset=utf-8');

    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "healthway";

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(["error" => "Error al conectar con la base de datos", "detalle" => $e->getMessage()]);
        exit;
    }

    try {
        // 🔹 Podés filtrar si querés solo las activas, por ejemplo:
        $stmt = $pdo->query("
            SELECT 
                i.IdInternacion,
                i.IdHabitacion,
                i.IdCama,
                i.EstadoInternacion,
                i.FechaInicio,
                i.FechaFin,
                CONCAT(u.Nombre, ' ', u.Apellido) AS NombrePaciente
            FROM internaciones i
            INNER JOIN pacientes p ON i.IdPaciente = p.IdPaciente
            INNER JOIN usuarios u ON p.IdUsuario = u.IdUsuario
            WHERE i.EstadoInternacion != 'Finalizada'
        ");

        $internaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode($internaciones);

    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(["error" => "Error al obtener las internaciones", "detalle" => $e->getMessage()]);
    }
?>