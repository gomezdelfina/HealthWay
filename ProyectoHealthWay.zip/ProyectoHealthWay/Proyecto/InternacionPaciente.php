<?php
    header('Content-Type: application/json;');

    // Conexión
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "healthway";

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(["error" => "Error de conexión a la base de datos", "detalle" => $e->getMessage()]);
        exit;
    }

    try {
        $sql = "SELECT p.IdPaciente, u.Nombre, u.Apellido, p.DNI
                FROM pacientes p
                INNER JOIN usuarios u ON p.IdUsuario = u.IdUsuario
                WHERE p.Estado = 'Normal'";
        
        $stmt = $pdo->query($sql);
        $pacientes = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode($pacientes, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;

    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(["error" => "Error al consultar los pacientes", "detalle" => $e->getMessage()]);
        exit;
    }
?>
